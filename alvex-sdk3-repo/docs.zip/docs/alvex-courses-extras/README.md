Alvex Courses Extras
====================

Different secondary materials and code snippets from Alvex courses
